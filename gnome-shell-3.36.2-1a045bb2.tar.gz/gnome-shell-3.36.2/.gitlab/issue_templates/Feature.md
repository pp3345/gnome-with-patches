<!-- 
Please read https://wiki.gnome.org/Community/GettingInTouch/BugReportingGuidelines
first to ensure that you create a clear and specific issue.
-->

### Feature summary

<!-- 
Describe what you would like to be able to do with GNOME Shell
that you currently cannot do.
-->

### How would you like it to work

<!-- 
If you can think of a way GNOME Shell might be able to do this,
let us know here.
-->

### Relevant links, screenshots, screencasts etc.

<!-- 
If you have further information, such as technical documentation,
code, mockups or a similar feature in another desktop environments,
please provide them here.
-->


<!-- Do not remove the following line. -->
/label ~"1. Feature"
