#define GETTEXT_PACKAGE "libgvc-test"
#define PACKAGE_VERSION "1.0-test"
#define HAVE_ALSA       1
