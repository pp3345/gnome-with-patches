#ifndef __CLUTTER_ACTOR_BOX_PRIVATE_H__
#define __CLUTTER_ACTOR_BOX_PRIVATE_H__

#include <clutter/clutter-types.h>

G_BEGIN_DECLS

void _clutter_actor_box_enlarge_for_effects (ClutterActorBox *box);

G_END_DECLS

#endif /* __CLUTTER_ACTOR_BOX_PRIVATE_H__ */
