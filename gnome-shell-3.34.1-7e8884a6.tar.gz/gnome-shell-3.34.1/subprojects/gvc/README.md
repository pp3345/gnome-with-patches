# libgnome-volume-control

libgnome-volume-control is a copy library that's supposed to be used as
a git sub-module. If your project uses some of libgnome-volume-control's
strings in a user-facing manner, don't forget to add those files to your
POTFILES.in for translation.

## Projects using libgnome-volume-control

- [gnome-shell](https://gitlab.gnome.org/GNOME/gnome-shell)
- [gnome-settings-daemon](https://gitlab.gnome.org/GNOME/gnome-settings-daemon)
- [gnome-control-center](https://gitlab.gnome.org/GNOME/gnome-control-center)
